MESH SOCIAL - Android app project
================================
This is a ready-to-build Android project. It wraps MESH_PUBLIC_SOCIAL_OFFLINE_3.html in a full-screen app
with the star icon on a black background. The app launches with the big star centered on black.

EASIEST (phone or computer, no software to install)
1. Make a free GitHub account, create a new repository, upload everything in this folder
   (keep the folders as they are, including .github).
2. Open the repository > Actions tab > "Build APK" > Run workflow. Wait about 5 minutes.
3. Open the finished run and download the artifact. Unzip it: app-debug.apk is your app.
4. Install it on your Android phone (allow "install unknown apps" when asked).

OR with Android Studio: File > Open this folder, then Build > Build APK(s).

Notes
- Needs internet only to connect to the mesh. Offline mode still works inside the app.
- For Google Play you will need a signed release build (Build > Generate Signed Bundle).
- To update the app later, replace app/src/main/assets/index.html, raise versionCode
  in app/build.gradle, and build again.
